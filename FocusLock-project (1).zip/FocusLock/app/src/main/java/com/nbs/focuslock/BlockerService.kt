package com.nbs.focuslock

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/**
 * While a lock is running, any window from a package that isn't allowed
 * (browsers, social media, Settings, Play Store, installer, launcher...) is
 * pushed back to the lock screen. Settings is blocked too, so the service
 * can't be switched off or the app uninstalled mid-session.
 */
class BlockerService : AccessibilityService() {
    private lateinit var repo: LockRepository
    private lateinit var controller: LockController
    private var allowed: Set<String> = emptySet()
    private var lastRefresh = 0L
    private var lastKick = 0L

    override fun onServiceConnected() {
        repo = PrefsLockRepository(this)
        controller = LockController(this)
        allowed = controller.allowedPackages()
        lastRefresh = SystemClock.elapsedRealtime()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (!::repo.isInitialized || !repo.isLocked()) return
        val pkg = event.packageName?.toString() ?: return

        val now = SystemClock.elapsedRealtime()
        if (now - lastRefresh > 60_000) { allowed = controller.allowedPackages(); lastRefresh = now }
        if (pkg in allowed) return
        if (now - lastKick < 400) return
        lastKick = now

        performGlobalAction(GLOBAL_ACTION_HOME)
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        } catch (_: Exception) {}
    }

    override fun onInterrupt() {}
}
