package com.nbs.focuslock

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Toast

enum class AppTarget(val label: String) {
    PHONE("Phone"), CONTACTS("Contacts"), WHATSAPP("WhatsApp"), GALLERY("Gallery")
}

class LockController(private val context: Context) {

    private val galleryPkgs = listOf(
        "com.google.android.apps.photos", "com.sec.android.gallery3d", "com.miui.gallery",
        "com.android.gallery3d", "com.coloros.gallery3d", "com.oneplus.gallery"
    )

    fun isServiceEnabled(): Boolean {
        val flat = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val cn = ComponentName(context, BlockerService::class.java)
        return flat.split(':').any {
            it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
        }
    }

    fun openAccessibilitySettings(activity: Activity) {
        activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    /** Everything NOT in this set gets kicked back to the lock screen. */
    fun allowedPackages(): Set<String> {
        val pm = context.packageManager
        val s = mutableSetOf(context.packageName, "com.android.systemui", "android")
        fun add(i: Intent) = pm.queryIntentActivities(i, PackageManager.MATCH_ALL).forEach { s.add(it.activityInfo.packageName) }
        add(Intent(Intent.ACTION_DIAL))
        add(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CONTACTS))
        add(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_GALLERY))
        s += galleryPkgs
        s += listOf(
            "com.whatsapp", "com.whatsapp.w4b",
            "com.android.server.telecom", "com.android.incallui", "com.android.phone",
            "com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer",
            "com.samsung.android.incallui", "com.android.contacts", "com.google.android.contacts",
            "com.samsung.android.app.contacts"
        )
        // keyboards, so you can type in WhatsApp
        try {
            context.getSystemService(InputMethodManager::class.java)
                .enabledInputMethodList.forEach { s.add(it.packageName) }
        } catch (_: Exception) {}
        return s
    }

    fun open(activity: Activity, target: AppTarget) {
        val pm = activity.packageManager
        val intent: Intent? = when (target) {
            AppTarget.PHONE -> Intent(Intent.ACTION_DIAL)
            AppTarget.CONTACTS -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CONTACTS)
            AppTarget.WHATSAPP -> pm.getLaunchIntentForPackage("com.whatsapp")
                ?: pm.getLaunchIntentForPackage("com.whatsapp.w4b")
            AppTarget.GALLERY -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_GALLERY)
                .takeIf { it.resolveActivity(pm) != null }
                ?: galleryPkgs.firstNotNullOfOrNull { pm.getLaunchIntentForPackage(it) }
        }
        if (intent == null) {
            Toast.makeText(activity, "${target.label} not found", Toast.LENGTH_SHORT).show(); return
        }
        try { activity.startActivity(intent) }
        catch (e: Exception) { Toast.makeText(activity, "Can't open ${target.label}", Toast.LENGTH_SHORT).show() }
    }
}
