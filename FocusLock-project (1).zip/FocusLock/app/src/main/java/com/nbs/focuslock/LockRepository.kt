package com.nbs.focuslock

import android.content.Context

/** Data layer: persists when the current lock ends, so a reboot can't dodge it. */
interface LockRepository {
    fun endTimeMillis(): Long
    fun start(minutes: Int)
    fun clear()
    fun isLocked(): Boolean = endTimeMillis() > System.currentTimeMillis()
}

class PrefsLockRepository(context: Context) : LockRepository {
    private val sp = context.getSharedPreferences("lock", Context.MODE_PRIVATE)
    override fun endTimeMillis() = sp.getLong("end", 0L)
    override fun start(minutes: Int) {
        sp.edit().putLong("end", System.currentTimeMillis() + minutes * 60_000L).apply()
    }
    override fun clear() { sp.edit().remove("end").apply() }
}
