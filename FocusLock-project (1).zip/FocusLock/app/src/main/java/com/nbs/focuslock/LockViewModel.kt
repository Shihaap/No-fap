package com.nbs.focuslock

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface LockUiState {
    data class Idle(val serviceEnabled: Boolean) : LockUiState
    data class Locked(val remainingSeconds: Long, val quote: String) : LockUiState
}

class LockViewModel(app: Application) : AndroidViewModel(app) {
    private val repo: LockRepository = PrefsLockRepository(app)
    val controller = LockController(app)

    private val quotes = listOf(
        "Discipline is choosing what you want most over what you want now.",
        "Your future self is watching. Make them proud.",
        "You don't need motivation. You need to start.",
        "Every minute you hold on is a vote for who you're becoming.",
        "Hard now, easy later. Easy now, hard later.",
        "The urge passes. Your goals don't.",
        "Be the builder, not the scroller.",
        "Small wins stack. Stay in it.",
        "You've got projects waiting. Go finish one.",
        "Nobody is coming to do it for you. Good thing you're capable."
    )

    private val _uiState = MutableStateFlow<LockUiState>(LockUiState.Idle(controller.isServiceEnabled()))
    val uiState: StateFlow<LockUiState> = _uiState.asStateFlow()
    private var job: Job? = null

    init { if (repo.isLocked()) runTimer() }

    fun refreshService() {
        if (_uiState.value is LockUiState.Idle) _uiState.value = LockUiState.Idle(controller.isServiceEnabled())
    }

    fun startLock(minutes: Int) {
        if (!controller.isServiceEnabled()) return
        repo.start(minutes)
        runTimer()
    }

    private fun runTimer() {
        job?.cancel()
        job = viewModelScope.launch {
            var tick = 0
            while (true) {
                val leftMs = repo.endTimeMillis() - System.currentTimeMillis()
                if (leftMs <= 0) break
                _uiState.value = LockUiState.Locked((leftMs + 999) / 1000, quotes[(tick / 8) % quotes.size])
                delay(1000); tick++
            }
            repo.clear()
            _uiState.value = LockUiState.Idle(controller.isServiceEnabled())
        }
    }
}
