Put your motivation video here, named exactly: motivation.mp4
