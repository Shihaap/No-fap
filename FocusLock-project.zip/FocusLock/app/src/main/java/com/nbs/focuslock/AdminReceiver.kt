package com.nbs.focuslock

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()
