package com.nbs.focuslock

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.widget.Toast

enum class AppTarget(val label: String) {
    PHONE("Phone"), CONTACTS("Contacts"), WHATSAPP("WhatsApp"), GALLERY("Gallery")
}

/** Wraps Android kiosk (lock task) APIs. Only works when the app is device owner. */
class LockController(private val context: Context) {
    private val dpm = context.getSystemService(DevicePolicyManager::class.java)
    private val admin = ComponentName(context, AdminReceiver::class.java)
    private val alias = ComponentName(context, "${context.packageName}.HomeAlias")

    val isDeviceOwner: Boolean get() = dpm.isDeviceOwnerApp(context.packageName)

    private val galleryPkgs = listOf(
        "com.google.android.apps.photos", "com.sec.android.gallery3d", "com.miui.gallery",
        "com.android.gallery3d", "com.coloros.gallery3d", "com.oneplus.gallery"
    )

    private fun allowedPackages(): Set<String> {
        val pm = context.packageManager
        val s = mutableSetOf(context.packageName)
        fun add(i: Intent) = pm.queryIntentActivities(i, PackageManager.MATCH_ALL).forEach { s.add(it.activityInfo.packageName) }
        add(Intent(Intent.ACTION_DIAL))
        add(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CONTACTS))
        add(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_GALLERY))
        s += galleryPkgs
        s += listOf(
            "com.whatsapp", "com.whatsapp.w4b",
            // dialer / in-call UI / contacts across brands (so calls always work)
            "com.android.server.telecom", "com.android.incallui", "com.android.phone",
            "com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer",
            "com.samsung.android.incallui", "com.android.contacts", "com.google.android.contacts",
            "com.samsung.android.app.contacts"
        )
        return s
    }

    fun engage(activity: Activity) {
        if (!isDeviceOwner) return
        dpm.setLockTaskPackages(admin, allowedPackages().toTypedArray())
        dpm.setLockTaskFeatures(admin, DevicePolicyManager.LOCK_TASK_FEATURE_HOME)
        context.packageManager.setComponentEnabledSetting(alias, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
        val f = IntentFilter(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME); addCategory(Intent.CATEGORY_DEFAULT)
        }
        dpm.addPersistentPreferredActivity(admin, f, alias)
        activity.startLockTask()
    }

    fun release(activity: Activity) {
        if (!isDeviceOwner) return
        try { dpm.clearPackagePersistentPreferredActivities(admin, context.packageName) } catch (_: Exception) {}
        try { activity.stopLockTask() } catch (_: Exception) {}
        try { dpm.setLockTaskPackages(admin, arrayOf()) } catch (_: Exception) {}
        context.packageManager.setComponentEnabledSetting(alias, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
    }

    fun open(activity: Activity, target: AppTarget) {
        val pm = activity.packageManager
        val intent: Intent? = when (target) {
            AppTarget.PHONE -> Intent(Intent.ACTION_DIAL)
            AppTarget.CONTACTS -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CONTACTS)
            AppTarget.WHATSAPP -> pm.getLaunchIntentForPackage("com.whatsapp")
                ?: pm.getLaunchIntentForPackage("com.whatsapp.w4b")
            AppTarget.GALLERY -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_GALLERY)
                .takeIf { it.resolveActivity(pm) != null }
                ?: galleryPkgs.firstNotNullOfOrNull { pm.getLaunchIntentForPackage(it) }
        }
        if (intent == null) {
            Toast.makeText(activity, "${target.label} not found", Toast.LENGTH_SHORT).show(); return
        }
        try { activity.startActivity(intent) }
        catch (e: Exception) { Toast.makeText(activity, "Can't open ${target.label}", Toast.LENGTH_SHORT).show() }
    }
}
