package com.nbs.focuslock

import android.app.Activity
import android.net.Uri
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

private val Bg = Color(0xFF0B0B0F)
private val Gold = Color(0xFFFFD54F)

@Composable
fun FocusLockApp(activity: Activity, vm: LockViewModel = viewModel()) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val locked = state is LockUiState.Locked

    BackHandler(enabled = locked) { /* no escape */ }
    LaunchedEffect(locked) {
        if (locked) vm.controller.engage(activity) else vm.controller.release(activity)
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        when (val s = state) {
            is LockUiState.Idle -> IdleScreen(s.isDeviceOwner, vm::startLock)
            is LockUiState.Locked -> LockedScreen(s) { vm.controller.open(activity, it) }
        }
    }
}

@Composable
private fun IdleScreen(isOwner: Boolean, onStart: (Int) -> Unit) {
    var minutes by remember { mutableIntStateOf(10) }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            if (isOwner) "Pick a time, hit the button.\nNo way out until it ends."
            else "One-time setup needed. On a PC with USB debugging on, run:\n\nadb shell dpm set-device-owner com.nbs.focuslock/.AdminReceiver",
            color = Color.White, fontSize = 16.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        listOf(10, 15, 20).forEach { m ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = minutes == m, onClick = { minutes = m })
                Text("$m min", color = Color.White)
            }
        }
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = { onStart(minutes) },
            enabled = isOwner,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
            modifier = Modifier.fillMaxWidth().height(64.dp)
        ) { Text("EMERGENCY", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun LockedScreen(state: LockUiState.Locked, onOpen: (AppTarget) -> Unit) {
    val ctx = LocalContext.current
    val videoUri = remember {
        val id = ctx.resources.getIdentifier("motivation", "raw", ctx.packageName)
        if (id != 0) Uri.parse("android.resource://${ctx.packageName}/$id") else null
    }
    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            "%02d:%02d".format(state.remainingSeconds / 60, state.remainingSeconds % 60),
            color = Color.White, fontSize = 52.sp, fontWeight = FontWeight.Bold
        )
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (videoUri != null) {
                AndroidView(
                    factory = { c ->
                        VideoView(c).apply {
                            setVideoURI(videoUri)
                            setOnPreparedListener { it.isLooping = true; start() }
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        Text(
            state.quote, color = Gold, fontSize = 20.sp, textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 24.dp)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AppTarget.entries.forEach { t ->
                Button(
                    onClick = { onOpen(t) },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(4.dp)
                ) { Text(t.label, fontSize = 12.sp, maxLines = 1) }
            }
        }
    }
}
